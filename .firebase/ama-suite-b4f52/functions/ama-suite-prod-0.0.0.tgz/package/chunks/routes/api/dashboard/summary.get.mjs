import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';

const summary_get = defineEventHandler(() => {
  return {
    monthlySales: 0,
    monthlyProfit: 0,
    productCount: 0,
    outOfStockCount: 0,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
});

export { summary_get as default };
//# sourceMappingURL=summary.get.mjs.map
