import { d as defineEventHandler, g as getRouterParam, r as readBody, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';

const memo_post = defineEventHandler(async (event) => {
  const asin = getRouterParam(event, "asin");
  const body = await readBody(event);
  if (!asin) {
    throw createError({ statusCode: 400, statusMessage: "ASIN\u304C\u6307\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093" });
  }
  return {
    asin,
    supplier: body.supplier,
    note: body.note,
    savedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
});

export { memo_post as default };
//# sourceMappingURL=memo.post.mjs.map
