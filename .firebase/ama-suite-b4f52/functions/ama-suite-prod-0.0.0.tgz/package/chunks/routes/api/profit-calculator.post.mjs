import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';

const FBA_FEE_RATE = 0.1;
const AMAZON_FEE_RATE = 0.08;
const profitCalculator_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const sellingPrice = Number(body.sellingPrice);
  const costPrice = Number(body.costPrice);
  if (!Number.isFinite(sellingPrice) || sellingPrice <= 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "sellingPrice \u306F\u6B63\u306E\u6570\u5024\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044"
    });
  }
  if (!Number.isFinite(costPrice) || costPrice < 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "costPrice \u306F0\u4EE5\u4E0A\u306E\u6570\u5024\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044"
    });
  }
  const fbaFee = Math.round(sellingPrice * FBA_FEE_RATE);
  const amazonFee = Math.round(sellingPrice * AMAZON_FEE_RATE);
  const profit = sellingPrice - costPrice - fbaFee - amazonFee;
  const profitRate = Math.round(profit / sellingPrice * 100);
  return {
    sellingPrice,
    costPrice,
    fbaFee,
    amazonFee,
    profit,
    profitRate
  };
});

export { profitCalculator_post as default };
//# sourceMappingURL=profit-calculator.post.mjs.map
