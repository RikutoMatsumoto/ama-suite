import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};export { J as handler, K as listener, L as websocket } from './chunks/nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';
//# sourceMappingURL=index.mjs.map
